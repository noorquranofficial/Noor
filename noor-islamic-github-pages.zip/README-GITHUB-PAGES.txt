NOOR ISLAMIC — GITHUB PAGES DEPLOYMENT (FIX FOR "File not found")
====================================================================

WHY YOU GOT THE ERROR
----------------------
GitHub Pages always looks for a file named exactly "index.html" sitting
directly in the root of your repository (or in a /docs folder, if you chose
that option in Settings). Your website file was named "noor-islamic.html",
so GitHub Pages had nothing to serve at your site's address — hence
"File not found."

THE FIX
--------
Nothing about your site's design, content, or features has changed.
The ONLY change is the file name: noor-islamic.html -> index.html.


WHAT'S IN THIS ZIP
--------------------
index.html   <-- this is your ENTIRE website: HTML + CSS + JavaScript,
                  all in this one file. There is no separate style.css or
                  script.js file, and none is needed — everything your site
                  needs is already inside index.html.

That's it. One file. No /css folder, no /js folder, no /images folder —
your site doesn't use any local image files, so none are required.


EXACTLY WHERE TO PUT IT IN YOUR GITHUB REPOSITORY
----------------------------------------------------
Repository root (top level) — NOT inside any subfolder:

  your-repo-name/
  └── index.html          <-- put it exactly here, at the top

If your repository currently has noor-islamic.html sitting in the root,
either:
  (a) delete it and upload this index.html in its place, or
  (b) rename noor-islamic.html to index.html directly on GitHub
      (open the file on github.com → pencil "Edit" icon → change the
      filename at the top → "Commit changes").


STEP-BY-STEP (if uploading fresh via the GitHub website)
------------------------------------------------------------
1. Open your repository on github.com
2. Click "Add file" → "Upload files"
3. Drag in index.html from this zip (make sure it lands in the root,
   not inside a folder)
4. Commit the changes
5. Go to Settings → Pages
6. Under "Build and deployment" → Source, choose "Deploy from a branch"
7. Branch: main (or master) — Folder: / (root)
8. Save, then wait 1-2 minutes
9. Your site will be live at:
   https://YOUR-GITHUB-USERNAME.github.io/YOUR-REPO-NAME/


A FEW GITHUB PAGES-SPECIFIC NOTES
------------------------------------
- GitHub Pages serves over https:// automatically, so the Prayer Times
  "Use my location" feature (which requires a secure https address) will
  work correctly once it's live.
- If your repository name is NOT username.github.io, your live URL will
  include the repository name at the end, e.g.
  https://yourname.github.io/noor-islamic/  — this is normal and the site
  still works the same way.
- Everything else (the EmailJS setup, the Sources & Licensing notes, the
  3 empty video categories) is unchanged from before — see the in-app
  "More -> Sources & Licensing" page for details.
